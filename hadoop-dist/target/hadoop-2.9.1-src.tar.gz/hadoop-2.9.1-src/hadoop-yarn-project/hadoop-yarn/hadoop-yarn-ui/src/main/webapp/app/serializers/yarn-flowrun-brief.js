/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import DS from 'ember-data';
import Converter from 'yarn-ui/utils/converter';

export default DS.JSONAPISerializer.extend({

    normalizeSingleResponse(store, primaryModelClass, payload, id,
      requestType) {
      var metrics = payload.metrics,
          cpuMetric = metrics.findBy('id', 'CPU'),
          cpu = cpuMetric? cpuMetric.values[Object.keys(cpuMetric.values)[0]] : -1,
          memMetric = metrics.findBy('id', 'MEMORY'),
          memory = memMetric? memMetric.values[Object.keys(memMetric.values)[0]] : -1;

      var fixedPayload = {
        id: id,
        type: primaryModelClass.modelName, // yarn-flowrun-brief
        attributes: {
          flowName: payload.info.SYSTEM_INFO_FLOW_NAME,
          runid: payload.info.SYSTEM_INFO_FLOW_RUN_ID,
          shownid: payload.id,
          type: payload.type,
          createTime: Converter.timeStampToDate(payload.createdtime),
          createTimeRaw: payload.createdtime,
          endTime: Converter.timeStampToDate(payload.info.SYSTEM_INFO_FLOW_RUN_END_TIME),
          endTimeRaw: payload.info.SYSTEM_INFO_FLOW_RUN_END_TIME || 0,
          user: payload.info.SYSTEM_INFO_USER,
          uid: payload.info.UID,
          cpuVCores: cpu,
          memoryUsed: memory
        }
      };

      return this._super(store, primaryModelClass, fixedPayload, id, requestType);
    },

    normalizeArrayResponse(store, primaryModelClass, payload, id, requestType) {
      var normalizedArrayResponse = {data: []};

      normalizedArrayResponse.data = payload.map(singleApp => {
        return this.normalizeSingleResponse(store, primaryModelClass,
          singleApp, singleApp.id, requestType);
      });

      return normalizedArrayResponse;
    }
});
